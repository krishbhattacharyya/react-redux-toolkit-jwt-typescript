import { useAppDispatch, useAppSelector } from "../../reduxutils/hooks"
import { Navigate } from "react-router-dom"
import {
  selectAuthUser,
  selectAuthError,
  selectAuthLoading,
  logInAsync,
  selectUserLoggedIn,
} from "../../reduxfeatures/auth/authSlice"
import Navigation from "../organisms/navigation/navigation"
import UserPasswordForm from "../organisms/userpasswordform/userPasswordForm"
import Container from "react-bootstrap/Container"
import Row from "react-bootstrap/Row"
import Col from "react-bootstrap/Col"

export default function LoginPageTemplate({
  heading,
  subHeading,
}: {
  heading: string
  subHeading: string
}) {
  const dispatch = useAppDispatch()
  const isLoading = useAppSelector(selectAuthLoading)
  const user = useAppSelector(selectAuthUser)
  const isError = useAppSelector(selectAuthError)
  const isLoggedIn = useAppSelector(selectUserLoggedIn)

  function formSubmitted(e: React.SyntheticEvent) {
    e.preventDefault()
    const target = e.target as typeof e.target & {
      email: { value: string }
      password: { value: string }
    }
    const emailId = target.email.value
    const password = target.password.value
    dispatch(logInAsync({ emailId, password }))
  }

  console.log(isLoggedIn)

  if (isLoggedIn) {
    return <Navigate to="/dashboard" />
  }
  return (
    <>
      <Navigation isLogin={isLoggedIn} user={user} />
      <Container>
        <Row>
          <Col>
            <h2>{heading}</h2>
          </Col>
        </Row>
        <Row>
          <Col>
            <h4>{subHeading}</h4>
          </Col>
        </Row>
        <Row>
          <Col>
            <UserPasswordForm
              submitButton={"Login"}
              formSubmitted={formSubmitted}
            />
          </Col>
        </Row>
        <Row>
          <Col>
            {isError ? isError : null}
            {isLoading ? "...loading" : null}
          </Col>
        </Row>
      </Container>
    </>
  )
}
