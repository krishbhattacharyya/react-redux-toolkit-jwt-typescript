import HomePageTemplate from "../templates/home-page-template";

const HomePage = () => {
    return (
      <HomePageTemplate heading={'Home Page'} image={'https://via.placeholder.com/600/d32776'} subHeading={'Welecome to demo site'} />
    )
  }
  
  export default HomePage;