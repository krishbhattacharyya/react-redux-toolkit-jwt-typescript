import ProductPageTemplate from "../templates/product-page-template";

const ProductPage = () => {
  return (
    <ProductPageTemplate heading={'Product Page'} image={''} subHeading={'Welecome to product site'} />
  )
}

export default ProductPage
