import DashboardPageTemplate from "../templates/dashboard-page-template";

const DashboardPage = () => {
  return (
    <DashboardPageTemplate heading={'Dashboard Page'} image={''} subHeading={'Welecome to demo site'} />
  )
}

export default DashboardPage
