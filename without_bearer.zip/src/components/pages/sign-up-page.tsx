import SignupPageTemplate from "../templates/signup-page-template"

const SignUpPage = () => {
  return (
    <SignupPageTemplate heading={'Sign Page'} subHeading={'Sign in to your Account, and get the most out of all the services you use'} />
  )
}

export default SignUpPage

