export const API = {
  SETCOOKIES: {
    URL: import.meta.env.VITE_API_BASE_URL + "setcookies",
    METHOD: "GET",
    PURPOSE: "Testing purpose cookie is working or not"
  },
  READCOOKIES: {
    URL: import.meta.env.VITE_API_BASE_URL + "readcookies",
    METHOD: "GET",
    PURPOSE: "Testing purpose cookie is working or not"
  },
  SIGNUPUSER: {
    URL: import.meta.env.VITE_API_BASE_URL + "auth/signup",
    METHOD: "POST",
    PURPOSE: "User signup with email and password"
  },
  LOGINUSER: {
    URL: import.meta.env.VITE_API_BASE_URL + "auth/login",
    METHOD: "POST",
    PURPOSE: "User login with email and password"
  },
  LOGOUTUSER: {
    URL: import.meta.env.VITE_API_BASE_URL + "auth/logout",
    METHOD: "GET",
    PURPOSE: "User logout destroying jwt"
  },
}
